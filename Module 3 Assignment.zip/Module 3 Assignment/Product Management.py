class Product:
    def __init__(self, product_id, name, price, quantity):
        self.product_id = product_id
        self.name = name
        self.price = price
        self.quantity = quantity

    def update_price(self, new_price):
        self.price = new_price

    def update_quantity(self, new_quantity):
        self.quantity = new_quantity

    def get_product_info(self):
        return {
            "Product ID": self.product_id,
            "Name": self.name,
            "Price": self.price,
            "Quantity": self.quantity
        }


class ProductManager:
    def __init__(self):
        self.products = {}

    def add_product(self, product):
        if product.product_id in self.products:
            raise ValueError("Product ID already exists.")
        self.products[product.product_id] = product

    def remove_product(self, product_id):
        if product_id not in self.products:
            raise ValueError("Product ID not found.")
        del self.products[product_id]

    def update_product(self, product_id, name=None, price=None, quantity=None):
        if product_id not in self.products:
            raise ValueError("Product ID not found.")
        product = self.products[product_id]
        if name:
            product.name = name
        if price:
            product.update_price(price)
        if quantity:
            product.update_quantity(quantity)

    def list_products(self):
        return [product.get_product_info() for product in self.products.values()]