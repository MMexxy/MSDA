
from datetime import datetime

class PaymentManager:
    def __init__(self,payments,reminders,penalties):
        self.payments = {}
        self.reminders_sent = {}
        self.penalties = {}
        
    def process_payment(self, payment_id: str, amount: float, payment_method: str) -> bool:
        """Process a new payment"""
        try:
            # Validate payment details
            if amount <= 0:
                return False
                
            # Store payment details
            self.payments[payment_id] = {
                'amount': amount,
                'method': payment_method,
                'status': 'processed',
                'timestamp': datetime.now()
            }
            return True
        except Exception:
            return False

    def send_payment_reminder(self, payment_id: str) -> bool:
        """Send payment reminder for overdue payments"""
        if payment_id not in self.payments:
            return False
            
        if payment_id not in self.reminders_sent:
            self.reminders_sent[payment_id] = 0
            
        self.reminders_sent[payment_id] += 1
        
        # Logic to send reminder (email/notification)
        reminder_message = f"Payment reminder #{self.reminders_sent[payment_id]} for payment {payment_id}"
        print(reminder_message)  
        
        return True

    def apply_late_penalty(self, payment_id: str, penalty_percentage: float) -> float:
        """Apply late payment penalty"""
        if payment_id not in self.payments:
            return 0.0
            
        payment = self.payments[payment_id]
        penalty_amount = payment['amount'] * (penalty_percentage / 100)
        
        if payment_id not in self.penalties:
            self.penalties[payment_id] = 0.0
            
        self.penalties[payment_id] += penalty_amount
        return penalty_amount

    def get_payment_status(self, payment_id: str) -> dict:
        """Get current status of a payment"""
        if payment_id not in self.payments:
            return {}
            
        status = self.payments[payment_id].copy()
        status['reminders_sent'] = self.reminders_sent.get(payment_id, 0)
        status['total_penalties'] = self.penalties.get(payment_id, 0.0)
        return status

    def get_total_payments(self) -> float:
        """Calculate total payments processed"""
        return sum(payment['amount'] for payment in self.payments.values())

    def get_total_penalties(self) -> float:
        """Calculate total penalties applied"""
        return sum(self.penalties.values())