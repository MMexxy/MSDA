
class PolicyHolder:
    def __init__(self, name, policy_number, contact_info):
        # Initialize policy holder with basic info
        self.name = name
        self.policy_number = policy_number
        self.contact_info = contact_info
        self.status = "inactive"
        self.registered = False

    def register(self):
        # Register a new policy holder
        if not self.registered:
            self.registered = True
            self.status = "active"
            return f"Policy holder {self.name} successfully registered with policy number {self.policy_number}"
        return "Policy holder already registered"

    def suspend(self):
        # Suspend an active policy holder
        if self.registered and self.status == "active":
            self.status = "suspended"
            return f"Policy holder {self.name} has been suspended"
        return "Cannot suspend - policy holder is not active"

    def reactivate(self):
        # Reactivate a suspended policy holder
        if self.registered and self.status == "suspended":
            self.status = "active"
            return f"Policy holder {self.name} has been reactivated"
        return "Cannot reactivate - policy holder is not suspended"

    def get_status(self):
        # Get current status of policy holder
        return f"Policy holder: {self.name}, Status: {self.status}"