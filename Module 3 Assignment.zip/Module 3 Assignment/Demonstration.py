
# Define PolicyHolder class to store policyholder information
class PolicyHolder:
    def __init__(self, name, age, policy_number, product, premium):
        self.name = name
        self.age = age
        self.policy_number = policy_number
        self.product = product
        self.premium = premium
        self.paid = False
        
    def make_payment(self):
        self.paid = True
        
    def display_details(self):
        payment_status = "Paid" if self.paid else "Unpaid"
        print(f"\nPolicyholder Details:")
        print(f"Name: {self.name}")
        print(f"Age: {self.age}")
        print(f"Policy Number: {self.policy_number}")
        print(f"Product: {self.product}")
        print(f"Premium Amount: ${self.premium}")
        print(f"Payment Status: {payment_status}")

# Create policyholder instances
holder1 = PolicyHolder("Amari Calvin", 20, "POL001", "Group Life Insurance", 4000)
holder2 = PolicyHolder("Maxmilla Muka", 35, "POL002", "Health Insurance", 6000)

# Make payments
holder1.make_payment()
holder2.make_payment()
print("Payments made successfully.")

# Display account details
holder1.display_details()
holder2.display_details()
print("Account details")    