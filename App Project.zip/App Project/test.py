from pymongo import MongoClient

client = MongoClient('mongodb://localhost:27017/')
collection = client['survey_db']['participants']

for doc in collection.find():
    print(doc)