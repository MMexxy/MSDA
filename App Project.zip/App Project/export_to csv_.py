from pymongo import MongoClient
import csv
import os

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')
collection = client['survey_db']['participants']

# Define all expected expense categories (ensure uniformity)
expense_categories = ['utilities', 'entertainment', 'school_fees', 'shopping', 'healthcare']

# Define full header
headers = ['Age', 'Gender', 'Total Income'] + [cat.title().replace('_', ' ') for cat in expense_categories]

# Output file
csv_file = 'data.csv'

with open(csv_file, 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(headers)  # write header

    for doc in collection.find():
        expenses = doc.get('expenses', {})

        row = [
            doc.get('age', ''),
            doc.get('gender', ''),
            doc.get('total_income', '')
        ]

        # Add expenses in fixed order
        for cat in expense_categories:
            row.append(expenses.get(cat, 0))

        writer.writerow(row)

print(f"Exported {collection.count_documents({})} records to {csv_file}")
