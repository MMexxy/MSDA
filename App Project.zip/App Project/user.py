import csv
import os

class User:
    def __init__(self, data):
        self.age = data.get('age')
        self.gender = data.get('gender')
        self.total_income = data.get('total_income')
        self.expenses = data.get('expenses', {})

    def save_to_csv(self, filename):
        # Extract unique expense categories from current data
        expense_keys = list(self.expenses.keys())

        # Define CSV headers
        headers = ['Age', 'Gender', 'Total Income'] + [key.title().replace('_', ' ') for key in expense_keys]

        file_exists = os.path.isfile(filename)

        with open(filename, 'a', newline='') as file:
            writer = csv.writer(file)

            # Write header only if file doesn't exist or is empty
            if not file_exists or os.path.getsize(filename) == 0:
                writer.writerow(headers)

            # Write the row with expenses aligned to headers
            row = [
                self.age,
                self.gender,
                self.total_income,
            ] + [self.expenses.get(key, 0) for key in expense_keys]

            writer.writerow(row)
