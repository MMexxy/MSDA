from flask import Flask, render_template, request, redirect
from pymongo import MongoClient
from user import User

app = Flask(__name__)
client = MongoClient('mongodb://localhost:27017/')
db = client['survey_db']
collection = db['participants']

@app.route('/', methods=['GET', 'POST'])
def survey():
    if request.method == 'POST':
        data = {
            'age': request.form.get('age'),
            'gender': request.form.get('gender'),
            'total_income': float(request.form.get('income', 0)),
            'expenses': {}
        }

        # List of all possible expense fields from the HTML
        expense_fields = [
            'rent', 'electricity', 'water', 'internet', 'phone',
            'groceries', 'dining_out',
            'fuel', 'public_transport', 'car_maintenance',
            'streaming', 'hobbies',
            'tuition', 'books',
            'insurance', 'medications',
            'clothing', 'electronics',
            'savings', 'other'
        ]

        # Check if the checkbox is ticked, and only then capture amount
        for field in expense_fields:
            if request.form.get(field):  # checkbox is ticked
                amount = request.form.get(f'{field}_amount', '0')
                try:
                    data['expenses'][field] = float(amount)
                except ValueError:
                    data['expenses'][field] = 0.0

        collection.insert_one(data)

        # Save to CSV using updated User class
        user = User(data)
        user.save_to_csv('data.csv')

        return redirect('/')

    return render_template('form.html')

if __name__ == '__main__':
    app.run(debug=True)
