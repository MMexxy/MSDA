set.seed(123)  # For reproducibility

# List Number of Workers
Workers <- 0:399
print(Workers)

# Generate WorkerID, Salary, Gender
WorkerID <- 1:400
Salary <- sample(5000:30000, 400, replace = TRUE)
Genders <- c("Male", "Female")
Gender <- sample(Genders, 400, replace = TRUE)

# Initialize empty data frame for payment slips
PaymentSlip <- data.frame(
  WorkerID = WorkerID,
  Salary = Salary,
  Gender = Gender,
  EmployeeLevel = rep("Z", 400),
  stringsAsFactors = FALSE
)

# Apply conditional logic
for (i in 1:400) {
  if (Salary[i] > 10000 && Salary[i] < 20000) {
    PaymentSlip$EmployeeLevel[i] <- "A1"
  }
  if (Salary[i] > 7500 && Salary[i] < 30000 && Gender[i] == "Female") {
    PaymentSlip$EmployeeLevel[i] <- "A5-F"
  }
}

# Print first few results
print(head(PaymentSlip, 10))

