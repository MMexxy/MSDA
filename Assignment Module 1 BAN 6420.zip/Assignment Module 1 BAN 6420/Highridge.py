import random
#List Number of workers
Workers = []
for i in range(0, 400):
    Workers.append(i)
print(Workers)
#Dictionary 
WorkerID = {}
for i in range(0, 400):
    WorkerID[i] = i+1
Salary = {}
for i in range(0, 400):
    Salary[i] = random.randint(5000, 30000)
Genders = ["Male", "Female"]
Gender = [random.choice(Genders) for _ in range(400)]

#print(WorkerID,Gender,Salary)

# Conditional statements
Paymentslip = []
for i in range(400):
    EmployeeLevel = "z"
    if 10000 < Salary[i] < 20000:
        EmployeeLevel = "A1"
    if 7500 < Salary[i] < 30000 and Gender[i] == "Female":
        EmployeeLevel = "A5-F"
    Paymentslip.append({
        "WorkerID": WorkerID[i],
        "Salary": Salary[i],
        "Gender": Gender[i],
        "EmployeeLevel": EmployeeLevel
    })

print(Paymentslip)