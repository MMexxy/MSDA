Highridge Construction Company

This is an automation process to generate 400 workers Payment slips using Python and R.

Unzip the Folder
To Run the Python script 
1. Double click on the file Highridge.py
2. A visual studio command environment opens
3. click run to run the script
4. output will be generated on the terminal

To Run the R script 
1. Double click on the file Highridge.r
2. Open with RStudio
3. Highlight the script (Do not miss this step)
3. click run to run the script
4. output will be generated on the terminal