# exportcsv.py
import csv
from pymongo import MongoClient
from urllib.parse import quote_plus

# Credentials
username = quote_plus("mexxy")
password = quote_plus("Amaricb@2024")
uri = f"mongodb+srv://{username}:{password}@mycluster.oabkvrs.mongodb.net/"

# Connect to MongoDB
client = MongoClient(uri)
db = client["SurveyTool"]
collection = db["Expenses"]

# Define CSV output file
output_file = "data.csv"

# Fetch data
documents = list(collection.find())

# Only export if there's data
if documents:
    # Use the keys from the first document as CSV headers, excluding '_id'
    keys = [key for key in documents[0].keys() if key != '_id']

    with open(output_file, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=keys)
        writer.writeheader()

        for doc in documents:
            del doc['_id']  # remove MongoDB ID field
            writer.writerow(doc)

    print(f"Exported {len(documents)} records to {output_file}")
else:
    print("No records found in MongoDB to export.")

