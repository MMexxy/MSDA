from flask import Flask, render_template, request, redirect
from pymongo import MongoClient
from urllib.parse import quote_plus 

app = Flask(__name__)
# Encode username and password
username = quote_plus("mexxy")
password = quote_plus("Amaricb@2024")  

# Connection string
uri = f"mongodb+srv://{username}:{password}@mycluster.oabkvrs.mongodb.net/"
# Replace with your real MongoDB Atlas URI
client = MongoClient(uri)
db = client["SurveyTool"] 
collection = db["Expenses"]  # your collection name

@app.route("/", methods=["GET", "POST"])
def survey():
    if request.method == "POST":
        # Grab form data
        data = {
            "age": int(request.form.get("age")),
            "gender": request.form.get("gender"),
            "totalMonthlyIncome": float(request.form.get("income")),
            "utilities": float(request.form.get("utilities_amount")),
            "entertainment": float(request.form.get("entertainment_amount")),
            "schoolFees": float(request.form.get("school_fees_amount")),
            "shopping": float(request.form.get("shopping_amount")),
            "healthcare": float(request.form.get("healthcare_amount"))
            
        }

        # Insert into MongoDB
        collection.insert_one(data)
        print("Data inserted:", data)

        return "Data submitted successfully!"

    return render_template("form.html")  # Your HTML file

if __name__ == "__main__":
    app.run(debug=True)

