# user.py
from pymongo import MongoClient
from urllib.parse import quote_plus

# Credentials
username = quote_plus("mexxy")
password = quote_plus("Amaricb@2024")
uri = f"mongodb+srv://{username}:{password}@mycluster.oabkvrs.mongodb.net/"

# Connect to MongoDB
client = MongoClient(uri)
db = client["SurveyTool"]
collection = db["Expenses"]

# Fetch and display all documents
print("User Submissions:")
for doc in collection.find():
    print(doc)

