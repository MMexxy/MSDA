# PCA Implementation on Breast Cancer Dataset
# Import necessary libraries
from sklearn.datasets import load_breast_cancer
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load the breast cancer dataset
cancer = load_breast_cancer()
X = cancer.data
y = cancer.target

# Scale the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Apply PCA
pca = PCA()
X_pca = pca.fit_transform(X_scaled)

# Calculate explained variance ratio
explained_variance_ratio = pca.explained_variance_ratio_

# Plot explained variance ratio
plt.plot(range(1, len(explained_variance_ratio) + 1), np.cumsum(explained_variance_ratio))
plt.xlabel('Number of Components')
plt.ylabel('Cumulative Explained Variance Ratio')
plt.title('Explained Variance Ratio vs Number of Components')

# Get number of components needed for 95% variance explained
n_components = np.argmax(np.cumsum(explained_variance_ratio) >= 0.95) + 1

# Create PCA with optimal number of components
pca_optimal = PCA(n_components=n_components)
X_pca_optimal = pca_optimal.fit_transform(X_scaled)

# Print feature names and their importance
for i, (component, variance) in enumerate(zip(pca_optimal.components_, pca_optimal.explained_variance_ratio_)):
    top_features = sorted(zip(cancer.feature_names, component), key=lambda x: abs(x[1]), reverse=True)[:3]
    print(f"\nPrincipal Component {i+1} (Explains {variance:.2%} of variance)")
    for feature, weight in top_features:
        print(f"{feature}: {weight:.4f}")