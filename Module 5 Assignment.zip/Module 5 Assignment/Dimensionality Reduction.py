
# Import required libraries
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import load_breast_cancer 
import pandas as pd

# Standardize the features
scaler = StandardScaler()
# Define X with example data (replace with your actual dataset)
import numpy as np
X = np.random.rand(100, 5) 
# Example data with 100 samples and 5 features
# Load the breast cancer dataset    

X_scaled = scaler.fit_transform(X)

# Apply PCA with 2 components
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

# Get explained variance ratio
explained_variance_ratio = pca.explained_variance_ratio_

# Create a DataFrame with PCA results
pca_df = pd.DataFrame(data=X_pca, columns=['PC1', 'PC2'])
print(pca_df.head())