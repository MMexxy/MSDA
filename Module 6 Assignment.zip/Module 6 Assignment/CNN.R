
# CNN model for Fashion MNIST classification using Keras in R
library(keras)

# Define CNN model class
FashionCNNModel <- R6::R6Class(
  "FashionCNNModel",
  public = list(
    model = NULL,
    
    # Initialize model architecture
    initialize = function() {
      self$model <- keras_model_sequential() %>%
        # Layer 1: Convolutional + ReLU + MaxPooling
        layer_conv_2d(filters = 32, kernel_size = c(3,3), activation = 'relu',
                     input_shape = c(28,28,1)) %>%
        layer_max_pooling_2d(pool_size = c(2,2)) %>%
        
        # Layer 2: Convolutional + ReLU + MaxPooling
        layer_conv_2d(filters = 64, kernel_size = c(3,3), activation = 'relu') %>%
        layer_max_pooling_2d(pool_size = c(2,2)) %>%
        
        # Layer 3: Convolutional + ReLU
        layer_conv_2d(filters = 64, kernel_size = c(3,3), activation = 'relu') %>%
        
        # Layer 4: Flatten
        layer_flatten() %>%
        
        # Layer 5: Dense + ReLU + Dropout
        layer_dense(units = 64, activation = 'relu') %>%
        layer_dropout(0.5) %>%
        
        # Layer 6: Dense output
        layer_dense(units = 10, activation = 'softmax')
      
      # Compile model
      self$model %>% compile(
        optimizer = 'adam',
        loss = 'sparse_categorical_crossentropy',
        metrics = c('accuracy')
      )
    },
    
    # Train model
    train = function(x_train, y_train, epochs = 10, batch_size = 32, validation_split = 0.2) {
      self$model %>% fit(
        x_train, y_train,
        epochs = epochs,
        batch_size = batch_size,
        validation_split = validation_split
      )
    },
    
    # Evaluate model
    evaluate = function(x_test, y_test) {
      self$model %>% evaluate(x_test, y_test)
    },
    
    # Make predictions
    predict = function(x) {
      self$model %>% predict(x)
    }
  

# Load and preprocess Fashion MNIST data
fashion_mnist <- dataset_fashion_mnist()

# Normalize pixel values
x_train <- fashion_mnist$train$x / 255
x_test <- fashion_mnist$test$x / 255

# Reshape arrays
x_train <- array_reshape(x_train, c(nrow(x_train), 28, 28, 1))
x_test <- array_reshape(x_test, c(nrow(x_test), 28, 28, 1))

# Create and train model
cnn_model <- FashionCNNModel$new()
history <- cnn_model$train(
  x_train, 
  fashion_mnist$train$y,
  epochs = 10,
  batch_size = 32,
  validation_split = 0.2
)

# Evaluate model
evaluation <- cnn_model$evaluate(x_test, fashion_mnist$test$y)
print(paste("Test accuracy:", evaluation[[2]]))