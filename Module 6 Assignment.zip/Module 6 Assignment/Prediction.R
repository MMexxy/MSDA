# Load required libraries
library(keras)

# Load Fashion MNIST dataset
fashion_mnist <- dataset_fashion_mnist()

# Split into training and test sets
x_train <- fashion_mnist$train$x
y_train <- fashion_mnist$train$y
x_test <- fashion_mnist$test$x
y_test <- fashion_mnist$test$y

# Normalize pixel values
x_train <- x_train / 255
x_test <- x_test / 255

# Define class names
class_names <- c('T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
                 'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot')

# Create a simple CNN model
model <- keras_model_sequential() %>%
  layer_flatten(input_shape = c(28, 28)) %>%
  layer_dense(units = 128, activation = 'relu') %>%
  layer_dense(units = 10, activation = 'softmax')

# Compile the model
model %>% compile(
  optimizer = 'adam',
  loss = 'sparse_categorical_crossentropy',
  metrics = c('accuracy')
)

# Train the model
model %>% fit(
  x_train, y_train,
  epochs = 5,
  validation_split = 0.2
)

# Make predictions for two test images
test_images <- x_test[1:2,,]
predictions <- model %>% predict(test_images)

# Print results
for(i in 1:2) {
  cat(sprintf("Image %d:\n", i))
  cat("Actual class:", class_names[y_test[i] + 1], "\n")
  cat("Predicted class:", class_names[which.max(predictions[i,])], "\n\n")
}
