import pandas as pd
import numpy as np
# Read the Netflix dataset
df = pd.read_csv('Netflix_shows_movies.csv')

# Check for missing values
missing_values = df.isnull().sum()

# Fill missing numeric values with mean
numeric_columns = df.select_dtypes(include=[np.number]).columns
df[numeric_columns] = df[numeric_columns].fillna(df[numeric_columns].mean())

# Fill missing categorical values with mode
categorical_columns = df.select_dtypes(include=['object']).columns
df[categorical_columns] = df[categorical_columns].fillna(df[categorical_columns].mode().iloc[0])

# Drop rows if still any missing values exist
df = df.dropna()

# Reset index after dropping rows
df = df.reset_index(drop=True)