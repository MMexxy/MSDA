# This script unzips the Netflix dataset and renames it to Netflix_shows_movies
import zipfile
import os
# Check if zip file exists before attempting to unzip
if os.path.exists('netflix_data.zip'):
    # Open and extract the zip file
    with zipfile.ZipFile('netflix_data.zip', 'r') as zip_ref:
        zip_ref.extractall()
        
        # Get the original filename from the zip contents
        original_filename = zip_ref.namelist()[0]
        
        # Rename extracted file to Netflix_shows_movies
        if os.path.exists(original_filename):
            os.rename(original_filename, 'Netflix_shows_movies.csv')
else:
    print("netflix_data.zip file not found")