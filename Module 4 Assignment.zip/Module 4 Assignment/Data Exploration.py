import pandas as pd
import numpy as np
# Read the Netflix dataset
df = pd.read_csv('Netflix_shows_movies.csv')
# Check for missing values  
print(df.isnull().sum())  
# Fill missing numeric values with mean
numeric_columns = df.select_dtypes(include=[np.number]).columns  
df[numeric_columns] = df[numeric_columns].fillna(df[numeric_columns].mean()) 
# Fill missing string values with mode
string_columns = df.select_dtypes(include=['object']).columns   
df[string_columns] = df[string_columns].fillna(df[string_columns].mode().iloc[0])
# Check for missing values again
print(df.isnull().sum()) 
# Remove rows with missing values
df = df.dropna()
#  basic statistics of numeric columns
print(df.describe())

# information about the dataset structure
print(df.info())

# Display unique values in categorical columns
for col in df.select_dtypes(include=['object']).columns:
    print(f"\nUnique values in {col}:")
    print(df[col].value_counts())

# Calculate correlation matrix for numeric columns
correlation_matrix = df[numeric_columns].corr()
print("\nCorrelation Matrix:")
print(correlation_matrix)

# Get basic statistics by category
for col in string_columns:
    print(f"\nSummary statistics grouped by {col}:")
    print(df.groupby(col)[numeric_columns].mean())

#  data distribution
for col in numeric_columns:
    print(f"\nSkewness of {col}: {df[col].skew()}")
    print(f"Kurtosis of {col}: {df[col].kurtosis()}")