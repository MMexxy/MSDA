library(ggplot2)   
library(dplyr)
library(tidyr)

# Generate Visualization using R  
  # Create sample data for movie genres and views
genre_data <- data.frame(
  genre = c("Action", "Comedy", "Drama", "Horror", "Sci-Fi", 
            "Romance", "Thriller", "Adventure", "Fantasy", "Animation"),
  views_millions = c(150, 130, 120, 90, 85, 
                    80, 75, 70, 65, 60)
)

# Create bar plot
ggplot(genre_data, aes(x = reorder(genre, -views_millions), y = views_millions)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  geom_text(aes(label = views_millions), vjust = -0.3) +
  labs(title = "Top 10 Most Watched Movie Genres",
       x = "Genre",
       y = "Views (Millions)") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  