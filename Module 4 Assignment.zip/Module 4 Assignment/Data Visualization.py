import seaborn as sns   
import matplotlib.pyplot as plt    
ImportError 
import pandas as pd
import numpy as np
# Data visualization
# Read the Netflix data
df = pd.read_csv('Netflix_shows_movies.csv')

# Remove rows with missing values
df_clean = df.dropna()

# Get top 10 genres
genre_counts = df_clean['listed_in'].value_counts().head(10)

# Create bar plot
plt.figure(figsize=(12,6))
sns.barplot(x=genre_counts.values, y=genre_counts.index)
plt.title('Top 10 Most Watched Genres on Netflix')
plt.xlabel('Number of Shows/Movies')
plt.ylabel('Genre')

# Add value labels on bars
for i, v in enumerate(genre_counts.values):
    plt.text(v, i, str(v), va='center')

plt.tight_layout()
plt.show()

# Create pie chart
plt.figure(figsize=(10,10))
plt.pie(genre_counts.values, labels=genre_counts.index, autopct='%1.1f%%')
plt.title('Distribution of Top 10 Netflix Genres')
plt.axis('equal')
plt.show()
# Create a scatter plot
plt.figure(figsize=(10, 6)) 
plt.scatter(df_clean['release_year'], df_clean['duration'], alpha=0.5)
plt.title('Release Year vs Duration of Netflix Shows/Movies')
plt.xlabel('Release Year')
plt.ylabel('Duration (minutes)')
plt.show()

# Create a box plot
# Create boxplot using seaborn
plt.figure(figsize=(10, 6))
sns.boxplot(data=df_clean, y='duration')
plt.title('Distribution of Duration of Netflix Shows/Movies')
plt.ylabel('Duration (minutes)')
plt.show()
plt.figure(figsize=(10, 6))