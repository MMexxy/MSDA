import matplotlib  as mpl
import matplotlib.pyplot as plt
import pandas as pd 
import seaborn as sns
import numpy as np

# Create visualization using line plot
# Read the Netflix dataset
df = pd.read_csv('Netflix_Shows_Movies.csv')

# Select 10 random movies
movies = df[df['type'] == 'Movie'].sample(n=10)

# Create line scatter plot
plt.figure(figsize=(12,6))
plt.plot(movies['title'], movies['rating'], 'o-', linewidth=2, markersize=10)

# Customize the plot
plt.xticks(rotation=45, ha='right')
plt.xlabel('Movie Title')
plt.ylabel('Rating')
plt.title('Rating Distribution for 10 Random Netflix Movies')
plt.grid(True, linestyle='--', alpha=0.7)

# Adjust layout to prevent label cutoff
plt.tight_layout()

# Show plot
plt.show()